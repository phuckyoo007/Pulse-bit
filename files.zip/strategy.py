"""
Discovers Kalshi's crypto up/down markets (KXBTC15M and equivalents),
figures out the strike + time remaining from each market's own fields,
and computes edge against the volatility model in vol_model.py.

Series tickers are discovered dynamically via get_series() rather than
hardcoded — Kalshi has renamed/rotated crypto series before, and
hardcoding a guess is exactly the mistake that caused real bugs earlier
in this project's sports version. Verify the printed series list the
first time you run this against your real account.
"""
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

from price_feed import get_spot_and_vol
from vol_model import probability_above_strike, probability_below_strike

# Kalshi series ticker prefixes to scan. KXBTC15M confirmed as of when
# this was written. XRP and BNB were confirmed as real, actively-traded
# 15-minute Kalshi crypto markets from a screenshot of Kalshi's own site
# (though the exact ticker string is still a best-guess at the naming
# pattern) -- ETH/SOL entries remain an unconfirmed guess too. Run
# find_crypto_series.py to verify every one of these before relying on
# them, the same way the sports bot's ticker guesses needed correcting
# once checked against real data.
CRYPTO_SERIES_PREFIXES = {
    # Trimmed to the core 7, per explicit request -- ADA, BCH, and TON
    # removed, keeping the original set that showed up most
    # consistently throughout this whole project.
    "KXBTC15M": "BTC",
    "KXETH15M": "ETH",
    "KXSOL15M": "SOL",
    "KXXRP15M": "XRP",
    "KXBNB15M": "BNB",
    "KXDOGE15M": "DOGE",
    "KXHYPE15M": "HYPE",
    # NEAR and ZEC both removed entirely per explicit request/earlier
    # evidence -- NEAR: three consecutive independent significance
    # checks (z=-1.98 at n=51, -1.99 at n=56, -2.00 at n=65) with zero
    # decay, even after already cutting its position size in half. The
    # most consistent, most trustworthy pattern found in this whole
    # project -- unlike every other "significant" result, which decayed
    # back to noise with more data.
}

# Hourly crypto markets, per explicit request -- same underlying
# coins, different (60-minute) window. Kept as its own dict so bot.py
# can distinguish these from the 15-minute markets above and apply a
# separate, more restrictive time filter (only the final 15 minutes of
# the hour, per explicit request -- the first 45 minutes are ignored
# entirely). Prefixes follow the confirmed KXBTCD pattern for hourly BTC.
HOURLY_CRYPTO_SERIES_PREFIXES = {
    # DISABLED per real evidence -- KXSOLD showed "SOL price on Jul 30,
    # 2026?" (a date-based title), strongly suggesting this is a daily
    # multi-strike ladder market, not hourly at all, and duplicate-
    # looking prints came from multiple different strikes under the
    # same series. Treating it as "last 15 min of an hour" was applying
    # the wrong restriction to the wrong kind of market entirely.
    # Re-enable only after confirming the real hourly prefix, if one exists.
}

_vol_cache = {}   # coin -> (spot, vol, fetched_at) -- refreshed per bot.py loop, not per market


def get_cached_spot_and_vol(coin: str, max_age_seconds: int = 30):
    import time
    cached = _vol_cache.get(coin)
    if cached and (time.time() - cached[2]) < max_age_seconds:
        return cached[0], cached[1]
    spot, vol = get_spot_and_vol(coin)
    _vol_cache[coin] = (spot, vol, time.time())
    return spot, vol


def discover_crypto_markets(client) -> list:
    """Pulls open markets across every series prefix in
    CRYPTO_SERIES_PREFIXES (15-min) and HOURLY_CRYPTO_SERIES_PREFIXES."""
    markets = []
    for prefix in {**CRYPTO_SERIES_PREFIXES, **HOURLY_CRYPTO_SERIES_PREFIXES}:
        try:
            resp = client.get_markets(status="open", series_ticker=prefix, limit=50)
            markets.extend(resp.get("markets", []))
        except Exception:
            continue   # a renamed/wrong prefix shouldn't take down the whole scan
    return markets


def _extract_strike(market: dict) -> Optional[float]:
    """Confirmed against a real Kalshi response: the strike lives in a
    top-level 'floor_strike' (or 'cap_strike') field, NOT inside
    custom_strike -- that field turned out to hold metadata like
    {"round_digits": "2"}, not a price. yes_sub_title also reliably
    contains it in this exact format: "Target Price: $64,115.86"."""
    for key in ("floor_strike", "cap_strike"):
        value = market.get(key)
        if value is not None:
            try:
                return float(value)
            except (TypeError, ValueError):
                pass

    match = re.search(r"Target Price:\s*\$?([\d,]+(?:\.\d+)?)", market.get("yes_sub_title", "") or "")
    if match:
        try:
            return float(match.group(1).replace(",", ""))
        except ValueError:
            pass

    # Legacy fallback -- kept only in case some market variant lacks the
    # fields above. Prone to grabbing an unrelated number from rules
    # text (e.g. "60" from "sixty seconds") -- this is what caused the
    # original bug, so don't trust this path without double-checking.
    custom = market.get("custom_strike") or {}
    for key in ("price", "strike", "threshold"):
        if key in custom:
            try:
                return float(custom[key])
            except (TypeError, ValueError):
                pass
    return None


def _extract_direction(market: dict) -> str:
    """Confirmed against real data: strike_type ('greater_or_equal' /
    'less_or_equal') is the reliable signal -- yes_sub_title does NOT
    reliably contain 'up'/'down' text (it's just the target price).
    'greater' (no '_or_equal') added after confirming the hourly KXBTCD
    market uses that exact value instead -- the title-based fallback
    below wouldn't have caught it either ("Bitcoin price on Jul 28,
    2026?" contains neither 'up' nor 'down')."""
    strike_type = market.get("strike_type", "")
    if strike_type in ("greater_or_equal", "greater"):
        return "above"
    if strike_type in ("less_or_equal", "less_than", "less"):
        return "below"
    title = (market.get("title", "") or "").lower()
    if "up" in title:
        return "above"
    if "down" in title:
        return "below"
    return "above"   # unconfirmed default -- flagged deliberately rather than silently guessing


def _time_to_expiry_years(market: dict) -> Optional[float]:
    close_time_str = market.get("close_time")
    if not close_time_str:
        return None
    close_time = datetime.fromisoformat(close_time_str.replace("Z", "+00:00"))
    now = datetime.now(timezone.utc)
    seconds_remaining = (close_time - now).total_seconds()
    if seconds_remaining <= 0:
        return None
    return seconds_remaining / (365.25 * 24 * 3600)


def discover_generic_short_markets(client) -> dict:
    """DISABLED per real evidence of misclassification -- a market
    titled "SOL price on Jul 30, 2026?" (a date-based, likely daily
    multi-strike ladder market) got matched by the title/tag heuristic
    below and treated as hourly, applying the wrong time restriction
    to the wrong kind of market entirely. Returns empty until this can
    be properly verified against real data -- see the commented-out
    body below for what it did.
    known_prefixes = set(CRYPTO_SERIES_PREFIXES) | set(HOURLY_CRYPTO_SERIES_PREFIXES)
    found = {}
    try:
        resp = client.get_series(limit=200)
    except Exception as e:
        print(f"Generic short-market series discovery failed: {e}")
        return found
    for s in resp.get("series", []):
        ticker = s.get("ticker", "")
        if ticker in known_prefixes:
            continue
        title = (s.get("title") or "").lower()
        tags = str(s.get("tags", [])).lower()
        category = s.get("category", "unknown")
        if "15 min" in title or "15min" in title or "15 minute" in title or "fifteen" in tags:
            found[ticker] = (category, "15min")
        elif "hour" in title or "hourly" in tags:
            found[ticker] = (category, "hourly")
    """
    return {}
    return found


@dataclass
class GenericPriceResult:
    """Pure price-based result for any non-crypto hourly market --
    deliberately has NO model_prob at all, matching the pure-price
    entry logic already used everywhere else in this bot."""
    ticker: str
    title: str
    category: str
    market_price: float
    seconds_remaining: float
    volume: float
    close_time: Optional[datetime] = None


def evaluate_generic_market(market: dict, category: str) -> Optional[GenericPriceResult]:
    close_time_str = market.get("close_time")
    close_time = None
    seconds_remaining = 0.0
    if close_time_str:
        close_time = datetime.fromisoformat(close_time_str.replace("Z", "+00:00"))
        seconds_remaining = (close_time - datetime.now(timezone.utc)).total_seconds()

    yes_ask = market.get("yes_ask_dollars")
    yes_bid = market.get("yes_bid_dollars")
    if yes_ask is None or yes_bid is None:
        return None
    market_price = (float(yes_ask) + float(yes_bid)) / 2

    return GenericPriceResult(
        ticker=market.get("ticker", ""),
        title=market.get("title", market.get("ticker", "")),
        category=category,
        market_price=market_price,
        seconds_remaining=seconds_remaining,
        volume=float(market.get("volume_fp", 0)),
        close_time=close_time,
    )


@dataclass
class CryptoEdgeResult:
    ticker: str
    title: str
    coin: str
    direction: str          # "above" or "below"
    market_price: float
    model_prob: float
    edge_pct: float
    seconds_remaining: float
    volume: float
    close_time: Optional[datetime] = None
    is_hourly: bool = False


def evaluate_crypto_market(market: dict) -> Optional[CryptoEdgeResult]:
    ticker = market["ticker"]
    coin = next((c for prefix, c in CRYPTO_SERIES_PREFIXES.items() if ticker.startswith(prefix)), None)
    is_hourly = False
    if not coin:
        coin = next((c for prefix, c in HOURLY_CRYPTO_SERIES_PREFIXES.items() if ticker.startswith(prefix)), None)
        is_hourly = coin is not None
    if not coin:
        return None

    strike = _extract_strike(market)
    time_to_expiry = _time_to_expiry_years(market)
    if strike is None or time_to_expiry is None:
        return None

    spot, vol = get_cached_spot_and_vol(coin)
    if spot is None or vol is None:
        return None

    direction = _extract_direction(market)
    if direction == "above":
        model_prob = probability_above_strike(spot, strike, time_to_expiry, vol)
    else:
        model_prob = probability_below_strike(spot, strike, time_to_expiry, vol)
    if model_prob is None:
        return None

    yes_ask = market.get("yes_ask_dollars")
    yes_bid = market.get("yes_bid_dollars")
    if yes_ask is None or yes_bid is None:
        return None
    market_price = (float(yes_ask) + float(yes_bid)) / 2
    edge_pct = (model_prob - market_price) * 100

    return CryptoEdgeResult(
        ticker=ticker,
        title=market.get("title", ticker),
        coin=coin,
        direction=direction,
        market_price=market_price,
        model_prob=model_prob,
        edge_pct=edge_pct,
        seconds_remaining=time_to_expiry * 365.25 * 24 * 3600,
        volume=float(market.get("volume_fp", 0)),
        close_time=datetime.fromisoformat(market["close_time"].replace("Z", "+00:00")) if market.get("close_time") else None,
        is_hourly=is_hourly,
    )
