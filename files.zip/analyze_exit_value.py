"""
The actual answer to "are our exit rules helping or hurting" -- not a
belief, a measurement. Aggregates exit_comparisons.json (built by
shadow_exit_tracking.py) by exit reason, and reports whether each rule's
early exits have, on average, actually beaten holding to natural
settlement.

Same discipline as every other analysis script here: needs a real
sample size before concluding anything, and reports the plain numbers
either way.

FEE CORRECTION: an early exit pays the entry fee AND an exit fee (two
trades); holding to natural settlement only ever pays the entry fee
(settlement itself isn't a trade you initiated). Every comparison here
is now fee-corrected using Kalshi's documented formula, so "was this
exit actually worth it" accounts for the extra cost early exits carry
that holding doesn't -- the raw, pre-fee numbers are shown too, for
reference.

Usage: python3 analyze_exit_value.py
"""
import json
from collections import defaultdict
from pathlib import Path

from apply_real_fees import fee_per_contract

MIN_SAMPLE_SIZE = 20   # exit comparisons accumulate slower than trades --
                        # only made when a market you exited early later
                        # finalizes -- so this bar is a bit lower than
                        # the 30 used elsewhere. Still a real bar.


def fee_corrected(row: dict) -> tuple:
    """Returns (actual_after_fees, if_held_after_fees). Actual paid the
    entry fee AND the exit fee (two trades); if_held only ever pays the
    entry fee."""
    entry_fee = fee_per_contract(row["entry_price"]) * row["count"]
    exit_fee = fee_per_contract(row["exit_value"]) * row["count"]
    actual_after_fees = row["pnl_actual"] - entry_fee - exit_fee
    if_held_after_fees = row["pnl_if_held"] - entry_fee
    return actual_after_fees, if_held_after_fees


def main():
    comparisons = json.loads(Path("exit_comparisons.json").read_text()) if Path("exit_comparisons.json").exists() else []

    if not comparisons:
        print("No exit comparisons recorded yet -- these only appear once a market you exited "
              "early has also finalized naturally, so this takes a while to accumulate.")
        return

    print(f"Total exit comparisons so far: {len(comparisons)}\n")

    by_reason = defaultdict(list)
    for c in comparisons:
        reason = c["exit_reason"].split(" (")[0]
        by_reason[reason].append(c)

    for reason, rows in sorted(by_reason.items()):
        total_actual_raw = sum(r["pnl_actual"] for r in rows)
        total_if_held_raw = sum(r["pnl_if_held"] for r in rows)

        fee_corrected_pairs = [fee_corrected(r) for r in rows]
        total_actual_fees = sum(p[0] for p in fee_corrected_pairs)
        total_if_held_fees = sum(p[1] for p in fee_corrected_pairs)
        total_diff_fees = total_actual_fees - total_if_held_fees
        better_count = sum(1 for a, h in fee_corrected_pairs if a > h)

        print(f"{reason} (n={len(rows)}):")
        print(f"  Raw (no fees):     actual=${total_actual_raw:+.2f}  if_held=${total_if_held_raw:+.2f}")
        print(f"  Fee-corrected:     actual=${total_actual_fees:+.2f}  if_held=${total_if_held_fees:+.2f}")
        print(f"  Net benefit of exiting (after real fees): ${total_diff_fees:+.2f}  "
              f"({better_count}/{len(rows)} were the right call)")

        if len(rows) < MIN_SAMPLE_SIZE:
            print(f"  -> Only {len(rows)} samples (need {MIN_SAMPLE_SIZE}+) -- too early to trust this yet.")
        elif total_diff_fees > 0:
            print(f"  -> This rule is EARNING its keep so far, even after the extra fee an early exit costs.")
        else:
            print(f"  -> This rule is actually COSTING you compared to just holding, once the extra "
                  f"exit-side fee is accounted for. Worth reconsidering.")
        print()


if __name__ == "__main__":
    main()
