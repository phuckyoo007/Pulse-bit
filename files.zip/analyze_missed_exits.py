"""
For every position where check_exits() logged a "would exit" decision
while EXIT_DRY_RUN was True, this finds that same ticker's REAL natural
settlement later on and compares the two -- telling you exactly how much
money the EXIT_DRY_RUN safety switch cost or saved you, instead of
guessing.

A positive "missed" total means exiting early would have done BETTER
than what actually happened -- real money left on the table by not
having exits live yet. A negative total means letting positions ride to
natural settlement instead of exiting early actually worked out BETTER
-- the safety switch protected you, not cost you.

Usage: python3 analyze_missed_exits.py
"""
import json
from pathlib import Path


def load(path):
    return json.loads(path.read_text()) if path.exists() else []


def main():
    settlements = load(Path("settlements.json"))
    trades = load(Path("trades.json"))

    # The critical filter: which tickers were REAL entries in the first
    # place. EXIT_DRY_RUN and DRY_RUN are separate switches -- an old
    # phantom-bankroll-era test position can still have a dry_run:true
    # exit-decision logged against it, which looks superficially similar
    # to a real position whose EXITS just hadn't been turned on yet.
    # Without this check, old test data with huge fake dollar amounts
    # (e.g. $467, sized against a phantom $1000 bankroll) gets included
    # as if it were real money -- exactly what happened before this fix.
    real_entry_tickers = {t["ticker"] for t in trades if t.get("dry_run") is False}

    # Last logged "would exit" decision per ticker, from when it was dry-run only.
    would_have_exited = {}
    for s in settlements:
        if s.get("result") == "early_exit" and s.get("dry_run") is True and s["ticker"] in real_entry_tickers:
            would_have_exited[s["ticker"]] = s   # keep overwriting -- ends up with the LAST one logged

    # Real natural settlements (not early exits) for those same tickers.
    natural_settlements = {}
    for s in settlements:
        if s.get("result") in ("yes", "no") and s["ticker"] in would_have_exited:
            natural_settlements[s["ticker"]] = s

    matched = []
    for ticker, exit_entry in would_have_exited.items():
        natural = natural_settlements.get(ticker)
        if natural is None:
            continue   # this position hasn't settled naturally yet, or never will -- can't compare
        matched.append({
            "ticker": ticker,
            "reason": exit_entry.get("exit_reason", "?"),
            "would_have_pnl": exit_entry["pnl"],
            "actual_pnl": natural["pnl"],
            "difference": exit_entry["pnl"] - natural["pnl"],   # positive = exiting would've been better (missed gain)
        })

    if not matched:
        print("No matched pairs found yet -- either no early-exit signals have fired, "
              "or none of those positions have gone on to settle naturally yet.")
        return

    total_actual = sum(m["actual_pnl"] for m in matched)
    total_would_have = sum(m["would_have_pnl"] for m in matched)
    total_missed = total_would_have - total_actual   # positive = you missed out by not exiting

    print(f"Found {len(matched)} position(s) with both a logged 'would exit' decision and a real natural settlement.\n")
    print(f"What actually happened (rode to natural settlement): ${total_actual:+.2f}")
    print(f"What would have happened (if those exits had been real): ${total_would_have:+.2f}")
    print(f"Difference: ${total_missed:+.2f}  "
          f"({'exiting would have done BETTER -- real money left on the table' if total_missed > 0 else 'letting them ride did BETTER -- the safety switch helped, not hurt'})\n")

    print("Per-position breakdown:")
    for m in sorted(matched, key=lambda x: abs(x["difference"]), reverse=True):
        print(f"  {m['ticker']:<32} reason={m['reason']:<20} "
              f"would_have=${m['would_have_pnl']:+.2f}  actual=${m['actual_pnl']:+.2f}  diff=${m['difference']:+.2f}")


if __name__ == "__main__":
    main()
