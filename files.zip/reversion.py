"""
A SEPARATE, UNPROVEN hypothesis from the main volatility model: tracks
each contract's own recent price history within its 15-minute life, and
flags when the current price has deviated unusually far from its own
short-term rolling average -- the "did it dip hard and might it revert"
signal.

IMPORTANT: this module only OBSERVES and LOGS. It does not place trades
or influence position sizing. That's deliberate. "Buy the dip because it
dipped" is a real, well-known failure mode (the gambler's fallacy applied
to a random walk) if there's nothing backing it beyond the dip itself --
a genuinely crashing asset punishes mechanical dip-buying badly. Before
this should ever touch a real trade, it needs the same treatment every
other real signal in this project got: log it, accumulate real
settlement outcomes, and run it through suggest_adjustments.py-style
significance testing to see if it's real or just noise that felt
compelling while watching a chart (which is a very common, very human,
very unreliable way to read price series -- hindsight makes every
random walk look like it had obvious turning points).
"""
from collections import deque, defaultdict
from dataclasses import dataclass
from typing import Optional

# How much recent price history (in ticks, roughly ~10s apart at the
# default poll interval) to use for the rolling average/stdev.
WINDOW_SIZE = 12   # roughly the last 2 minutes at a 10s poll interval

_price_history = defaultdict(lambda: deque(maxlen=WINDOW_SIZE))


@dataclass
class ReversionSignal:
    ticker: str
    current_price: float
    rolling_mean: float
    rolling_stdev: float
    z_score: Optional[float]   # how many stdevs the current price is from its own recent mean


def record_and_score(ticker: str, current_price: float) -> ReversionSignal:
    """Call this once per market per loop -- records the current price
    into that ticker's rolling history, then scores how far the current
    price sits from its own recent trend. A large negative z-score means
    the price has dipped well below where it's recently been trading; a
    large positive z-score means it's spiked well above."""
    history = _price_history[ticker]
    history.append(current_price)

    if len(history) < 4:   # not enough history yet for a meaningful stdev
        return ReversionSignal(ticker, current_price, current_price, 0.0, None)

    mean = sum(history) / len(history)
    variance = sum((p - mean) ** 2 for p in history) / (len(history) - 1)
    stdev = variance ** 0.5

    if stdev == 0:
        return ReversionSignal(ticker, current_price, mean, 0.0, None)

    z = (current_price - mean) / stdev
    return ReversionSignal(ticker, current_price, round(mean, 4), round(stdev, 4), round(z, 3))


def cleanup_stale_tickers(active_tickers: set):
    """Call periodically to stop tracking tickers that are no longer
    being scanned (their 15-minute window closed) -- keeps memory bounded
    instead of accumulating every ticker ever seen."""
    for ticker in list(_price_history.keys()):
        if ticker not in active_tickers:
            del _price_history[ticker]
