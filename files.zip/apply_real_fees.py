"""
Every pnl number we've looked at so far has been the RAW price
difference -- entry vs exit or entry vs settlement. None of it has
subtracted Kalshi's actual trading fee. This recomputes real net pnl
using Kalshi's documented fee formula, so we can see whether the
reported profit survives real costs.

Kalshi's taker fee (confirmed via Kalshi's own published fee schedule):
    fee_per_contract = fee_multiplier * price * (1 - price)
Peaks at ~1.75 cents per contract at a 50-cent price (max uncertainty),
shrinking toward the extremes. fee_multiplier is ~0.07 for most
categories -- sports may run higher per some sources, but 0.07 is used
here as the documented baseline; treat sports-category results as a
lower bound on the true fee if that turns out to be too low.

A position incurs this fee on ENTRY always. If it was closed early
(has an exit_price/exit_value in the settlement record) it incurs the
fee AGAIN on exit. A position held to natural settlement only pays the
one entry-side fee -- settlement itself isn't a trade you initiated.

Usage: python3 apply_real_fees.py
"""
import json
from pathlib import Path

FEE_MULTIPLIER = 0.07


def fee_per_contract(price: float) -> float:
    return FEE_MULTIPLIER * price * (1 - price)


def main():
    trades = [t for t in json.loads(Path("trades.json").read_text()) if t.get("dry_run") is False] \
        if Path("trades.json").exists() else []
    settlements = [s for s in json.loads(Path("settlements.json").read_text()) if s.get("dry_run") is False] \
        if Path("settlements.json").exists() else []

    if not settlements:
        print("No real settled trades found -- nothing to recompute.")
        return

    trades_by_ticker = {t["ticker"]: t for t in trades}

    total_raw_pnl = 0.0
    total_fees = 0.0
    total_real_pnl = 0.0
    rows = []

    for s in settlements:
        t = trades_by_ticker.get(s["ticker"])
        entry_price = s.get("entry_price") or (t.get("price") if t else None)
        count = s.get("count") or (t.get("count") if t else None)
        if entry_price is None or count is None:
            continue

        raw_pnl = s["pnl"]
        entry_fee = fee_per_contract(entry_price) * count
        exit_fee = 0.0
        if s.get("exit_price") is not None or s.get("exit_value") is not None:
            exit_price = s.get("exit_price", s.get("exit_value"))
            exit_fee = fee_per_contract(exit_price) * count

        fees = entry_fee + exit_fee
        real_pnl = raw_pnl - fees

        total_raw_pnl += raw_pnl
        total_fees += fees
        total_real_pnl += real_pnl
        rows.append({"ticker": s["ticker"], "raw_pnl": raw_pnl, "fees": fees, "real_pnl": real_pnl})

    print(f"Real settled trades analyzed: {len(rows)}\n")
    print(f"Raw pnl (what every analysis script has shown so far):  ${total_raw_pnl:+.2f}")
    print(f"Total real Kalshi fees (never subtracted until now):    ${total_fees:.2f}")
    print(f"ACTUAL net pnl after real fees:                          ${total_real_pnl:+.2f}")
    print()

    if total_real_pnl > 0 and total_raw_pnl > 0:
        pct_eaten = (total_fees / total_raw_pnl * 100) if total_raw_pnl else 0
        print(f"Fees ate {pct_eaten:.1f}% of the raw profit, but it's still net positive after them.")
    elif total_raw_pnl > 0 and total_real_pnl <= 0:
        print("The reported profit does NOT survive real fees -- what looked like a real edge may "
              "actually be a net loss once you account for what Kalshi actually charges.")
    else:
        print("Already negative before fees -- fees make an already-losing picture worse.")


if __name__ == "__main__":
    main()
