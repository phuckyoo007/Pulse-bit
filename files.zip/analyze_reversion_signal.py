"""
Tests the dip/reversion hypothesis against REAL settled trades: does
entering when a contract has dipped hard relative to its own recent
trading (a strongly negative reversion_z) actually predict a better
outcome than entries with no such signal? Or is it noise that looked
compelling on a chart but doesn't hold up in real outcomes?

Same discipline as suggest_adjustments.py: requires a real minimum
sample size, runs an actual significance test, and refuses to conclude
anything from too little data. This is deliberately NOT wired into any
trading decision -- it's purely a check on whether the reversion.py
signal is worth trusting at all.

Usage: python3 analyze_reversion_signal.py
"""
import json
import math
from pathlib import Path

MIN_SAMPLE_SIZE = 30
SIGNIFICANCE_Z = 1.96
STRONG_Z_THRESHOLD = 1.5   # how extreme reversion_z_at_entry needs to be to count as a "real dip/spike"


def load(path):
    return json.loads(path.read_text()) if path.exists() else []


def two_proportion_z_test(wins_a, n_a, wins_b, n_b):
    if n_a == 0 or n_b == 0:
        return None
    p_a, p_b = wins_a / n_a, wins_b / n_b
    p_pool = (wins_a + wins_b) / (n_a + n_b)
    se = math.sqrt(p_pool * (1 - p_pool) * (1 / n_a + 1 / n_b))
    if se == 0:
        return None
    return (p_a - p_b) / se


def main():
    trades = [t for t in load(Path("trades.json")) if t.get("dry_run") is False]
    settlements = [s for s in load(Path("settlements.json")) if s.get("dry_run") is False]
    trades_by_ticker = {t["ticker"]: t for t in trades}

    joined = []
    for s in settlements:
        t = trades_by_ticker.get(s["ticker"])
        if not t or t.get("reversion_z_at_entry") is None:
            continue   # only include entries that actually have a reversion signal recorded
        joined.append({"pnl": s["pnl"], "reversion_z": t["reversion_z_at_entry"], "side": t.get("side")})

    print(f"Found {len(joined)} real settled trades with a recorded reversion signal.\n")

    if len(joined) < MIN_SAMPLE_SIZE * 2:
        print(f"Not enough real trades with this signal yet ({len(joined)}) to test anything. "
              f"Need at least {MIN_SAMPLE_SIZE} in the 'strong dip/spike' group and "
              f"{MIN_SAMPLE_SIZE} in the baseline group before this can say anything real.")
        return

    strong = [r for r in joined if abs(r["reversion_z"]) >= STRONG_Z_THRESHOLD]
    baseline = [r for r in joined if abs(r["reversion_z"]) < STRONG_Z_THRESHOLD]

    if len(strong) < MIN_SAMPLE_SIZE or len(baseline) < MIN_SAMPLE_SIZE:
        print(f"Strong-signal group: n={len(strong)}, baseline group: n={len(baseline)} -- "
              f"at least one is still under {MIN_SAMPLE_SIZE}. Not enough yet to test.")
        return

    wins_strong = sum(1 for r in strong if r["pnl"] > 0)
    wins_baseline = sum(1 for r in baseline if r["pnl"] > 0)
    wr_strong = wins_strong / len(strong) * 100
    wr_baseline = wins_baseline / len(baseline) * 100
    pnl_strong = sum(r["pnl"] for r in strong)
    pnl_baseline = sum(r["pnl"] for r in baseline)

    z = two_proportion_z_test(wins_strong, len(strong), wins_baseline, len(baseline))

    print(f"Strong dip/spike entries (|z| >= {STRONG_Z_THRESHOLD}): n={len(strong)}, "
          f"win_rate={wr_strong:.1f}%, total_pnl=${pnl_strong:+.2f}")
    print(f"Baseline entries (|z| < {STRONG_Z_THRESHOLD}):          n={len(baseline)}, "
          f"win_rate={wr_baseline:.1f}%, total_pnl=${pnl_baseline:+.2f}")

    if z is not None and abs(z) >= SIGNIFICANCE_Z:
        direction = "BETTER" if wr_strong > wr_baseline else "WORSE"
        print(f"\nStatistically significant (z={z:.2f}): strong dip/spike entries perform {direction} "
              f"than baseline. This is real signal, not (just) noise -- worth considering wiring "
              f"into actual entry/sizing logic.")
    else:
        z_display = f"{z:.2f}" if z is not None else "N/A"
        print(f"\nNot statistically significant (z={z_display}). No real evidence yet "
              f"that this signal predicts anything beyond noise. Keep logging, don't trade on it yet.")


if __name__ == "__main__":
    main()
