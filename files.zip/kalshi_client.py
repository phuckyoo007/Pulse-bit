"""
Thin Kalshi REST client: RSA-PSS request signing plus wrapper methods for
the endpoints this bot needs.

A note on order schema, honestly: Kalshi's order API is mid-transition as
of 2026 — order *reads* stay on /portfolio/orders, but order *writes* have
moved to a newer /portfolio/events/orders endpoint using a "bid"/"ask"
side model instead of the older "yes"/"no" + "buy"/"sell" model most
tutorials still describe. This client follows the newer model, matching
Kalshi's own current quick-start docs at the time this was written:

    side="bid"  → you're placing a buy order on the YES contract
                  (long "yes" — betting the event happens)
    side="ask"  → you're placing a sell order on the YES contract
                  (equivalent to going long "no" if you don't already
                  hold yes shares — betting the event doesn't happen)

This mapping is my best current read of Kalshi's docs, not something
I've verified by executing a real trade. Test it in the demo environment
(the default) and confirm a small order behaves the way you expect
before trusting it with real money.
"""
import base64
import time
from urllib.parse import urlparse

import requests
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

from config import Config


class KalshiClient:
    def __init__(self):
        Config.validate()
        self.base_url = Config.base_url()
        with open(Config.PRIVATE_KEY_PATH, "rb") as f:
            self.private_key = serialization.load_pem_private_key(f.read(), password=None)

    def _sign(self, method: str, path: str) -> dict:
        timestamp_ms = str(int(time.time() * 1000))
        message = f"{timestamp_ms}{method}{path}".encode("utf-8")
        signature = self.private_key.sign(
            message,
            padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=32),
            hashes.SHA256(),
        )
        return {
            "KALSHI-ACCESS-KEY": Config.API_KEY_ID,
            "KALSHI-ACCESS-TIMESTAMP": timestamp_ms,
            "KALSHI-ACCESS-SIGNATURE": base64.b64encode(signature).decode("utf-8"),
            "Content-Type": "application/json",
        }

    def _request(self, method: str, path: str, params=None, json_body=None):
        url = self.base_url + path
        sign_path = urlparse(url).path   # sign the path only, never the query string
        headers = self._sign(method, sign_path)
        resp = requests.request(method, url, headers=headers, params=params, json=json_body, timeout=15)
        if not resp.ok:
            # Kalshi's actual error message (e.g. which field was wrong) is in
            # the response body -- the default raise_for_status() discards it,
            # which makes a bad order body nearly impossible to debug.
            try:
                detail = resp.json()
            except ValueError:
                detail = resp.text
            raise requests.exceptions.HTTPError(
                f"{resp.status_code} error from Kalshi on {method} {path}: {detail}"
            )
        return resp.json()

    # --- Market data (these work unauthenticated too, but signed headers are harmless) ---

    def get_markets(self, status="open", series_ticker=None, event_ticker=None, limit=100, cursor=None):
        params = {"status": status, "limit": limit}
        if series_ticker:
            params["series_ticker"] = series_ticker
        if event_ticker:
            params["event_ticker"] = event_ticker
        if cursor:
            params["cursor"] = cursor
        return self._request("GET", "/markets", params=params)

    def get_series(self, category: str = None, tags: str = None, limit: int = 200):
        params = {"limit": limit}
        if category:
            params["category"] = category
        if tags:
            params["tags"] = tags
        return self._request("GET", "/series", params=params)

    def get_market(self, ticker: str):
        return self._request("GET", f"/markets/{ticker}")

    def get_orderbook(self, ticker: str):
        return self._request("GET", f"/markets/{ticker}/orderbook")

    # --- Portfolio (require real auth) ---

    def get_balance(self):
        return self._request("GET", "/portfolio/balance")

    def get_deposits(self, limit: int = 100):
        """Real, confirmed endpoint (Kalshi's own docs: get_deposits --
        'Endpoint for getting the member's deposit history'). Used to
        tell real deposits apart from trading pnl when reconciling
        balance drift -- without this, a deposit looks identical to an
        unexplained pnl discrepancy."""
        return self._request("GET", "/portfolio/deposits", params={"limit": limit})

    def get_fills(self, limit: int = 100, cursor: str = None):
        """Real, confirmed endpoint. Returns actual executed fills,
        including the REAL fee charged per fill -- everywhere else in
        this project has used a FORMULA to ESTIMATE fees, never this.
        Useful for retrospective analysis (was the estimate close?);
        can't be used for real-time exit decisions since a fill for a
        trade that hasn't happened yet doesn't exist."""
        params = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        return self._request("GET", "/portfolio/fills", params=params)

    def get_positions(self):
        return self._request("GET", "/portfolio/positions")

    def create_order(self, ticker: str, client_order_id: str, side: str, count: str, price: str,
                      time_in_force: str = "good_till_canceled"):
        """side: 'bid' (buy yes) or 'ask' (sell yes / effectively long no) — see module docstring."""
        body = {
            "ticker": ticker,
            "client_order_id": client_order_id,
            "side": side,
            "count": count,             # decimal string, e.g. "10"
            "price": price,             # decimal string in DOLLARS, e.g. "0.65" for 65 cents
            "time_in_force": time_in_force,
            "self_trade_prevention_type": "taker_at_cross",
        }
        return self._request("POST", "/portfolio/events/orders", json_body=body)

    def cancel_order(self, order_id: str):
        return self._request("DELETE", f"/portfolio/events/orders/{order_id}")
