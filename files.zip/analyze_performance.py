"""
Joins trades.json (entries) with settlements.json (outcomes) to compute
real win rate -- filtered to dry_run=False only, same fix as everywhere
else in this project, since unfiltered data mixes in old phantom-bankroll
test trades and gives nonsense numbers.

More usefully: breaks win rate down by edge size and by how much time was
left when the trade was entered. The math we've already worked through
says entries very close to expiry are the noisiest (tiny denominator in
the pricing model amplifies small errors into big-looking edges) -- this
checks whether that's actually true in your real results, instead of
just assuming it.

Usage:
    python3 analyze_performance.py           (all real settled trades, all time)
    python3 analyze_performance.py 3         (only trades settled in the last 3 hours)
"""
import json
import sys
import time
from collections import defaultdict
from pathlib import Path

TRADES_FILE = Path("trades.json")
SETTLEMENTS_FILE = Path("settlements.json")


def load(path):
    return json.loads(path.read_text()) if path.exists() else []


def bucket_edge(edge_pct):
    e = abs(edge_pct)
    if e < 10:
        return "8-10pp"
    if e < 15:
        return "10-15pp"
    if e < 25:
        return "15-25pp"
    return "25pp+"


def bucket_time(seconds):
    if seconds is None:
        return "unknown"
    if seconds < 120:
        return "45-120s (near expiry)"
    if seconds < 300:
        return "2-5 min"
    return "5min+"


def win_rate(rows):
    if not rows:
        return None, 0
    wins = sum(1 for r in rows if r["pnl"] > 0)
    return wins / len(rows) * 100, len(rows)


def print_breakdown(title, rows, key_fn):
    print(f"\n{title}")
    groups = defaultdict(list)
    for r in rows:
        groups[key_fn(r)].append(r)
    for key in sorted(groups.keys()):
        group = groups[key]
        wr, n = win_rate(group)
        avg_pnl = sum(r["pnl"] for r in group) / len(group)
        total_pnl = sum(r["pnl"] for r in group)
        print(f"  {key:<24} n={n:<4} win_rate={wr:5.1f}%  avg_pnl=${avg_pnl:+.3f}  total=${total_pnl:+.2f}")


def main():
    hours = None
    if len(sys.argv) > 1:
        try:
            hours = float(sys.argv[1])
        except ValueError:
            print(f"'{sys.argv[1]}' isn't a number of hours -- ignoring it, showing all-time results instead.")

    trades = [t for t in load(TRADES_FILE) if t.get("dry_run") is False]
    settlements = [s for s in load(SETTLEMENTS_FILE) if s.get("dry_run") is False]

    if hours is not None:
        cutoff = time.time() - hours * 3600
        settlements = [s for s in settlements if s.get("timestamp", 0) >= cutoff]

    trades_by_ticker = {t["ticker"]: t for t in trades}

    joined = []
    for s in settlements:
        t = trades_by_ticker.get(s["ticker"])
        joined.append({
            "ticker": s["ticker"], "pnl": s["pnl"], "coin": s.get("coin") or (t.get("coin") if t else "?"),
            "edge_pct": t.get("edge_pct") if t else None,
            "seconds_remaining_at_entry": t.get("seconds_remaining_at_entry") if t else None,
        })

    window_label = f"last {hours:g} hour(s)" if hours is not None else "all time"
    if not joined:
        print(f"No real (dry_run=False) settled trades found in the {window_label} -- nothing to analyze.")
        return

    overall_wr, n = win_rate(joined)
    total_pnl = sum(r["pnl"] for r in joined)
    print(f"OVERALL ({window_label}): {n} real settled trades, win rate={overall_wr:.1f}%, total pnl=${total_pnl:+.2f}")

    has_edge_data = any(r["edge_pct"] is not None for r in joined)
    has_time_data = any(r["seconds_remaining_at_entry"] is not None for r in joined)

    print_breakdown("By coin:", joined, lambda r: r["coin"])

    if has_edge_data:
        print_breakdown("By edge size at entry:", [r for r in joined if r["edge_pct"] is not None],
                         lambda r: bucket_edge(r["edge_pct"]))
    else:
        print("\nBy edge size: no data (these trades predate logging edge_pct into trades.json)")

    if has_time_data:
        print_breakdown("By time remaining at entry:", [r for r in joined if r["seconds_remaining_at_entry"] is not None],
                         lambda r: bucket_time(r["seconds_remaining_at_entry"]))
    else:
        print("\nBy time remaining: no data yet -- this field was just added, "
              "so only trades entered AFTER this update will have it. Run this again after more real trades settle.")


if __name__ == "__main__":
    main()
