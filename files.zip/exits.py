"""
Early-exit logic for open positions, separate from entry logic on purpose
-- deciding whether to close something you already hold is a different
question from deciding whether to open it.

Six rules, checked in this order (most urgent first):

  1. STOP-LOSS: the position has moved against you sharply. Exit now,
     regardless of time left, to cap the loss rather than ride it to zero.
  2. MODEL REVERSAL: the model's current read has flipped to favor the
     OPPOSITE side of what you're holding, by a real margin -- the
     informational basis for the trade no longer holds.
  3. TAKE-PROFIT: the position has gained a large multiple of what you
     paid, period -- regardless of time left or short-term statistics.
     This is the plain "you're up a lot, take it" rule -- none of the
     other rules actually cover this case. A position that climbed
     slowly and steadily can show an unremarkable short-term signal (rule
     5 below) even with a huge total gain since entry, and might have
     plenty of time left (rule 6 below doesn't apply yet either) -- this
     rule exists specifically to not miss that.
  4. MODEST PROFIT: catches smaller gains that don't reach take-profit's
     4x bar but are still clearly worth capturing -- "clearly" meaning
     the gain comfortably exceeds the REAL round-trip fee cost of
     exiting (confirmed via Kalshi's documented fee formula, see
     apply_real_fees.py). This deliberately does NOT fire on every
     positive cent: exiting on a gain that's smaller than (or close to)
     what the extra exit-side fee costs would lock in a loss while
     looking like a win. Only fires once the gain clearly clears that
     bar by a real margin.
  5. REVERSION RECOVERY: the contract's own price has swung back up well
     above its recent trading range (per reversion.py), and the position
     is currently profitable. Takes the recovery gain rather than riding
     it further, on the same "unproven hypothesis" basis as the entry
     side of this signal -- see reversion.py's own caveats.
  6. LOCK-IN NEAR EXPIRY: very little time left, and the position is
     currently worth close to its maximum payout. Selling now takes a
     slightly lower guaranteed amount instead of the full payout, in
     exchange for removing the small remaining risk of a last-second
     reversal. This is a risk/reward trade-off, not extra profit --
     said plainly in case it reads as "free money" at a glance.
"""
from dataclasses import dataclass
from typing import Optional

from apply_real_fees import fee_per_contract

STOP_LOSS_FRACTION = 0.30     # set to 30% of entry (70% loss allowed) per explicit request -- e.g. 90c entry exits at 27c
MODEL_REVERSAL_MARGIN_PP = 20.0   # widened from 10.0 -- real data showed this rule firing 19
                                   # times in 30 minutes on Pulse, each one paying two real fees
                                   # (entry + exit) instead of the one fee natural settlement
                                   # costs. The model is known to be sensitive (verified
                                   # mathematically elsewhere in this project), so a tight
                                   # threshold was likely just catching normal wobble, not real
                                   # reversals -- widening it requires a bigger, more genuine
                                   # move before exiting.
TAKE_PROFIT_MULTIPLE = 4.0     # exit once value has reached 4x what you paid, any time, any category
MODEST_PROFIT_FEE_MULTIPLE = 3.0   # gain per contract must be at least this many times the
                                    # estimated round-trip fee before counting as "clearly worth capturing"
CAPTURE_PROFIT_MIN_GAIN = 0.10   # changed to 10c per explicit request, as one of two profit-taking thresholds
VALUE_CAPTURE_THRESHOLD = 0.98   # exit once value reaches this, regardless of gain size, per explicit request
REVERSION_RECOVERY_Z_THRESHOLD = 1.0   # exit a profitable dip-buy once price has recovered this far above its recent trend
LOCK_IN_SECONDS = 45           # only consider locking in gains inside this window before close
LOCK_IN_MIN_VALUE_FRACTION = 0.80   # ...and only if current value is at least this fraction of max payout


@dataclass
class ExitDecision:
    should_exit: bool
    reason: str = ""


def current_position_value(position: dict, current_market_price: float) -> float:
    """What your held position is worth right now, per contract, if you
    closed it at the current price. A 'bid' (long yes) position's value
    IS the current yes price; an 'ask' (long no) position's value is
    (1 - current yes price)."""
    if position["side"] == "bid":
        return current_market_price
    return 1 - current_market_price


def check_exit(position: dict, current_market_price: float, current_model_prob: float,
                seconds_remaining: float, reversion_z: Optional[float] = None,
                partial_profit_fraction: Optional[float] = None,
                peak_gain_per_contract: Optional[float] = None) -> ExitDecision:
    entry_price = position["entry_price"]
    side = position["side"]
    value_now = current_position_value(position, current_market_price)

    # Rule 1: stop-loss -- at a 30% loss threshold, per explicit
    # request. Value has fallen sharply below what you paid.
    # FIXED: added an epsilon guard -- entry_price * STOP_LOSS_FRACTION
    # can compute as e.g. 0.27999999999999997 instead of exactly 0.28
    # due to float precision, which silently failed to trigger for a
    # position landing exactly at the intended threshold.
    if value_now <= entry_price * STOP_LOSS_FRACTION + 1e-9:
        return ExitDecision(True, f"stop_loss (value ${value_now:.2f} vs entry ${entry_price:.2f})")

    # Rule 2: model reversal -- DISABLED per the same explicit request.
    # if side == "bid" -> model_support_for_your_side = current_model_prob; if "ask" -> 1 - current_model_prob.
    # if model_support_for_your_side < 0.5 - (MODEL_REVERSAL_MARGIN_PP / 100):
    #     return ExitDecision(True, "model_reversal ...")

    # Rule 3: take-profit -- DISABLED per explicit request ("hold till
    # it closes, settlement only"). Left here, commented out:
    # if entry_price > 0 and value_now >= entry_price * TAKE_PROFIT_MULTIPLE:
    #     return ExitDecision(True, f"take_profit (value ${value_now:.2f} is {value_now/entry_price:.1f}x entry ${entry_price:.2f})")

    # Rule 3.5: partial profit -- DISABLED per the same explicit request.
    # if partial_profit_fraction is not None and entry_price > 0 and value_now >= entry_price * (1 + partial_profit_fraction):
    #     return ExitDecision(True, "partial_profit ...")

    # Rule 3.6: capture profit -- back to a single condition, per
    # explicit request. The 98% value-threshold rule below is
    # DISABLED again; only the 10-cent gain fires now. Below that,
    # positions hold to full natural settlement (or stop_loss, which
    # stays active).
    if entry_price > 0:
        gain = value_now - entry_price
        if gain >= CAPTURE_PROFIT_MIN_GAIN - 1e-9:
            return ExitDecision(True, f"capture_profit (gained ${gain:.3f}/contract, value ${value_now:.2f} "
                                       f"vs entry ${entry_price:.2f})")
        # if value_now >= VALUE_CAPTURE_THRESHOLD - 1e-9:
        #     return ExitDecision(True, "capture_profit_value_threshold ...")

    # Rule 4: modest profit -- DISABLED per the same explicit request.
    # gain_per_contract = value_now - entry_price
    # if gain_per_contract > 0:
    #     round_trip_fee = fee_per_contract(entry_price) + fee_per_contract(value_now)
    #     if gain_per_contract >= MODEST_PROFIT_FEE_MULTIPLE * round_trip_fee:
    #         return ExitDecision(True, "modest_profit ...")

    # Rule 5: reversion recovery -- DISABLED per explicit request.
    # Only fires for 'bid' (long yes) positions, matching the entry side
    # reversion.py's dip signal buys. Left here, commented out, so it's
    # easy to re-enable later:
    # if side == "bid" and reversion_z is not None and reversion_z >= REVERSION_RECOVERY_Z_THRESHOLD and value_now > entry_price:
    #     return ExitDecision(True, f"reversion_recovery (z={reversion_z}, value ${value_now:.2f} vs entry ${entry_price:.2f})")

    # Rule 6: lock in a near-expiry gain -- DISABLED per the same
    # explicit request. Every position now rides to natural settlement
    # only; check_exit() will return should_exit=False in every case
    # from here on, and check_settlements() in bot.py is what actually
    # closes each position out, once Kalshi settles it.
    # if seconds_remaining <= LOCK_IN_SECONDS and value_now >= LOCK_IN_MIN_VALUE_FRACTION:
    #     return ExitDecision(True, f"lock_in_near_expiry (value ${value_now:.2f}, {int(seconds_remaining)}s left)")

    return ExitDecision(False)
